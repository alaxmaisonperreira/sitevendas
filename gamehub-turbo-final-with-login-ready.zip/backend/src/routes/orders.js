const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// create checkout session
router.post('/create-checkout-session', body('productId').isInt(), async (req,res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
  const { productId } = req.body;
  const r = await pool.query('SELECT * FROM products WHERE id=$1', [productId]);
  const product = r.rows[0];
  if (!product) return res.status(404).json({ error: 'Product not found' });

  const ord = await pool.query('INSERT INTO orders (user_id,product_id,amount,status) VALUES ($1,$2,$3,$4) RETURNING *',
    [req.body.user_id || null, productId, product.price, 'pending']);

  if (process.env.STRIPE_SECRET_KEY) {
    const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
    try {
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [{
          price_data: {
            currency: 'brl',
            product_data: { name: product.title },
            unit_amount: Math.round(Number(product.price) * 100),
          },
          quantity: 1
        }],
        success_url: (process.env.FRONTEND_URL || 'http://localhost:3000') + '/success?session_id={CHECKOUT_SESSION_ID}',
        cancel_url: (process.env.FRONTEND_URL || 'http://localhost:3000') + '/cancel',
        metadata: { orderId: ord.rows[0].id.toString() }
      });
      return res.json({ sessionId: session.id, orderId: ord.rows[0].id });
    } catch (err) {
      console.error('Stripe error', err);
      return res.status(500).json({ error: 'Stripe error' });
    }
  }

  res.json({ sessionId: 'mock_' + ord.rows[0].id, orderId: ord.rows[0].id });
});

module.exports = router;

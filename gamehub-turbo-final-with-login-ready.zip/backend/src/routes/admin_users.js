const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const auth = require('../middleware/auth');
const roles = require('../middleware/roles');

// GET /api/admin/users  (admin only)
router.get('/users', auth, roles.requireRole('admin'), async (req,res) => {
  const { rows } = await pool.query('SELECT id, name, email, role, created_at FROM users ORDER BY id DESC LIMIT 100');
  res.json(rows);
});

// GET /api/admin/orders (admin only)
router.get('/orders', auth, roles.requireRole('admin'), async (req,res) => {
  const { rows } = await pool.query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 100');
  res.json(rows);
});

module.exports = router;

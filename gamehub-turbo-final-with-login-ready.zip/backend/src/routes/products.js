const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const auth = require('../middleware/auth');
const roles = require('../middleware/roles');

// GET products (public)
router.get('/', async (req,res) => {
  const { rows } = await pool.query('SELECT p.*, u.name as seller_name FROM products p LEFT JOIN users u ON p.seller_id = u.id ORDER BY p.created_at DESC');
  res.json(rows);
});

// POST create (seller only)
router.post('/', auth, roles.requireRole('seller'),
  body('title').notEmpty(), body('price').isFloat({ gt: 0 }), async (req,res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
  const { title, description, price, category, auto_delivery } = req.body;
  const seller_id = req.user.id;
  const r = await pool.query('INSERT INTO products (title,description,price,category,auto_delivery,seller_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
    [title,description,price,category,auto_delivery,seller_id]);
  res.json(r.rows[0]);
});

module.exports = router;

/*
 Image upload example using multer + Cloudinary.
 Requires CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET in backend/.env
*/
const express = require('express');
const router = express.Router();
const multer = require('multer');
const cloudinary = require('cloudinary').v2;
const streamifier = require('streamifier');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

const storage = multer.memoryStorage();
const upload = multer({ storage });

router.post('/image', upload.single('image'), async (req,res) => {
  if(!req.file) return res.status(400).json({ error: 'No file' });
  try {
    const stream = cloudinary.uploader.upload_stream({ folder: 'gamehub' }, (error, result) => {
      if (error) return res.status(500).json({ error });
      res.json({ url: result.secure_url });
    });
    streamifier.createReadStream(req.file.buffer).pipe(stream);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

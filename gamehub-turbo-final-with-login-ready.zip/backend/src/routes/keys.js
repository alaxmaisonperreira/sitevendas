const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// GET available keys
router.get('/available/:productId', async (req,res) => {
  const { rows } = await pool.query('SELECT id,code FROM keys WHERE product_id=$1 AND allocated=false LIMIT 10', [req.params.productId]);
  res.json(rows);
});

// POST allocate (internal)
router.post('/allocate', async (req,res) => {
  const { orderId, productId } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM keys WHERE product_id=$1 AND allocated=false LIMIT 1 FOR UPDATE', [productId]);
    if (r.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No keys' });
    }
    const key = r.rows[0];
    await client.query('UPDATE keys SET allocated=true WHERE id=$1', [key.id]);
    await client.query('UPDATE orders SET status=$1 WHERE id=$2', ['completed', orderId]);
    await client.query('COMMIT');
    res.json({ key: key.code });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Allocation error' });
  } finally {
    client.release();
  }
});

module.exports = router;

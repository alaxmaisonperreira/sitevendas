const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// helper
function signAccess(user) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '15m' });
}
function signRefresh(user) {
  return jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET || 'dev_refresh', { expiresIn: '30d' });
}

// POST /api/auth/register
router.post('/register',
  body('email').isEmail(),
  body('password').isLength({ min: 6 }),
  async (req,res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });

  const { name, email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  const result = await pool.query('INSERT INTO users (name,email,password_hash,role) VALUES ($1,$2,$3,$4) RETURNING id,name,email,role', [name,email,hash,'buyer']);
  const user = result.rows[0];
  const access = signAccess(user);
  const refresh = signRefresh(user);
  await pool.query('UPDATE users SET refresh_token=$1 WHERE id=$2', [refresh, user.id]);
  res.json({ user, accessToken: access, refreshToken: refresh });
});

// POST /api/auth/login
router.post('/login', body('email').isEmail(), async (req,res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
  const { email, password } = req.body;
  const r = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = r.rows[0];
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const access = signAccess(user);
  const refresh = signRefresh(user);
  await pool.query('UPDATE users SET refresh_token=$1 WHERE id=$2', [refresh, user.id]);
  res.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role }, accessToken: access, refreshToken: refresh });
});

// POST /api/auth/refresh
router.post('/refresh', async (req,res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: 'No token' });
  try {
    const payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET || 'dev_refresh');
    const r = await pool.query('SELECT * FROM users WHERE id=$1', [payload.id]);
    const user = r.rows[0];
    if (!user || user.refresh_token !== token) return res.status(401).json({ error: 'Invalid refresh' });
    const access = signAccess(user);
    res.json({ accessToken: access });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
});

module.exports = router;

require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { Pool } = require('pg');
const sentry = require('./sentry');


const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000' }));
app.use(express.json({ limit: '10kb' }));

const apiLimiter = rateLimit({ windowMs: 15*60*1000, max: 200, standardHeaders: true, legacyHeaders: false });
app.use('/api/', apiLimiter);

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.get('/api/health', (req,res) => res.json({ ok:true }));

// mount routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/keys', require('./routes/keys'));
app.use('/api/uploads', require('./routes/uploads'));
app.use('/api/admin', require('./routes/admin_users'));

// Stripe webhook; use raw body to verify signature
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
if (endpointSecret) {
  const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');
  app.post('/webhook', express.raw({ type: 'application/json' }), (req,res) => {
    const sig = req.headers['stripe-signature'];
    let event;
    try {
      event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } catch (err) {
      console.error('Webhook sig verify failed', err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      console.log('Checkout complete:', session.id, session.metadata);
      // TODO: find order by metadata.orderId and deliver keys
    }
    res.json({ received: true });
  });
} else {
  app.post('/webhook', (req,res) => res.json({ received: true }));
}

// Run migrations on start (simple)
const sqlPath = path.join(__dirname, 'db', 'migrations.sql');
if (fs.existsSync(sqlPath)) {
  const sql = fs.readFileSync(sqlPath, 'utf8');
  pool.query(sql).then(()=>console.log('Migrations executed')).catch(err=>console.error('Migrations error',err));
}

const PORT = process.env.PORT || 4000;
sentry.init();
pool.connect().then(()=> {
  app.listen(PORT, ()=> console.log('Backend running on', PORT));
}).catch(err => {
  console.error('DB connection error', err);
  process.exit(1);
});

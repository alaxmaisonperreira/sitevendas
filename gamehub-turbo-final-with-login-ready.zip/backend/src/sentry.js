/*
 Optional Sentry integration.
 Set SENTRY_DSN in backend/.env to enable.
*/
const Sentry = require('@sentry/node');

function init() {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  Sentry.init({ dsn, tracesSampleRate: 0.1 });
  console.log('Sentry initialized');
}

module.exports = { init, Sentry };

/*
 Seed script to create admin, seller, buyer, sample products and keys.
*/
const { Pool } = require('pg');
const bcrypt = require('bcrypt');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://postgres:postgres@db:5432/postgres',
});

async function run() {
  try {
    await pool.query(`
    CREATE TABLE IF NOT EXISTS users(
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'buyer'
    );
    CREATE TABLE IF NOT EXISTS products(
      id SERIAL PRIMARY KEY,
      seller_id INT REFERENCES users(id),
      title TEXT NOT NULL,
      description TEXT,
      price_cents INT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS keys(
      id SERIAL PRIMARY KEY,
      product_id INT REFERENCES products(id),
      code TEXT NOT NULL,
      delivered BOOLEAN DEFAULT false
    );
    `);

    const hashAdmin = await bcrypt.hash('admin123', 10);
    const hashSeller = await bcrypt.hash('seller123', 10);
    const hashBuyer = await bcrypt.hash('buyer123', 10);

    const { rows: admins } = await pool.query('SELECT * FROM users WHERE email=$1',['admin@gamehub.com']);
    if(admins.length===0){
      await pool.query('INSERT INTO users(email,password,role) VALUES ($1,$2,$3)',
        ['admin@gamehub.com', hashAdmin, 'admin']);
    }

    const { rows: sellers } = await pool.query('SELECT * FROM users WHERE email=$1',['seller@gamehub.com']);
    let sellerId;
    if(sellers.length===0){
      const ins = await pool.query('INSERT INTO users(email,password,role) VALUES ($1,$2,$3) RETURNING id',
        ['seller@gamehub.com', hashSeller, 'seller']);
      sellerId = ins.rows[0].id;
    } else {
      sellerId = sellers[0].id;
    }

    const { rows: buyers } = await pool.query('SELECT * FROM users WHERE email=$1',['buyer@gamehub.com']);
    if(buyers.length===0){
      await pool.query('INSERT INTO users(email,password,role) VALUES ($1,$2,$3)',
        ['buyer@gamehub.com', hashBuyer, 'buyer']);
    }

    if(sellerId){
      const { rows: prods } = await pool.query('SELECT * FROM products WHERE seller_id=$1',[sellerId]);
      if(prods.length===0){
        const p1 = await pool.query('INSERT INTO products(seller_id,title,description,price_cents) VALUES ($1,$2,$3,$4) RETURNING id',
          [sellerId,'Jogo A','Um jogo de teste A', 1999]);
        const p2 = await pool.query('INSERT INTO products(seller_id,title,description,price_cents) VALUES ($1,$2,$3,$4) RETURNING id',
          [sellerId,'Jogo B','Um jogo de teste B', 2999]);
        await pool.query('INSERT INTO keys(product_id,code) VALUES ($1,$2),($1,$3)',
          [p1.rows[0].id,'AAAA-BBBB-CCCC','DDDD-EEEE-FFFF']);
        await pool.query('INSERT INTO keys(product_id,code) VALUES ($1,$2),($1,$3)',
          [p2.rows[0].id,'GGGG-HHHH-IIII','JJJJ-KKKK-LLLL']);
      }
    }

    console.log('Seed completo: admin, seller, buyer e produtos criados.');
    process.exit(0);
  } catch(err) {
    console.error('Erro no seed',err);
    process.exit(1);
  }
}

run();

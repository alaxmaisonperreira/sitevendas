import './globals.css'
import AuthProvider from './auth/AuthProvider'
import AuthNav from './auth/AuthNav'

export const metadata = {
  title: 'GameHub Turbo',
  description: 'Marketplace de jogos'
}

export default function RootLayout({ children }) {

  // Sentry can be initialized here in _app or a separate client entry if NEXT_PUBLIC_SENTRY_DSN is set

  return (
    <html lang="pt-BR">
      <body>
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-lg font-bold">GameHub Turbo</div>
          <div className="flex items-center gap-3">
            <AuthNav />
            <a href="/" className="text-sm">Início</a>
            <a href="/dashboard/seller" className="text-sm">Vendedor</a>
            <a href="/dashboard/admin" className="text-sm">Admin</a>
            <a href="/checkout" className="text-sm">Checkout</a>
          </div>
        </div>
      </nav><AuthProvider>{children}</AuthProvider></body>
    </html>
  )
}

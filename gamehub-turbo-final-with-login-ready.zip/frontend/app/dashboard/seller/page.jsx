'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '../../auth/AuthProvider';
import { useRouter } from 'next/navigation';
import api from '../../../lib/api';

export default function SellerDashboard() {
  const auth = useAuth();
  const router = useRouter();
  useEffect(()=>{ if(!auth.user) router.push('/login'); if(auth.user && auth.user.role !== 'seller') router.push('/login'); }, [auth.user]);
  const [products, setProducts] = useState([]);
  const [keys, setKeys] = useState([]);
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState(9.9);
  const apiBase = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

  useEffect(() => {
    async function load() {
      try {
        const res = await api.get('/products');
        setProducts(res.data || []);
      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, []);

  async function createProduct() {
    try {
      // In production you must send Authorization: Bearer <token>
      await api.post('/products', { title, description: '', price, category: 'Outros', auto_delivery: true, seller_id: null });
      alert('Produto criado (verifique backend)');
      setTitle(''); setPrice(9.9);
    } catch (err) {
      console.error(err);
      alert('Erro ao criar produto. Verifique se está autenticado.');
    }
  }

  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Painel do Vendedor</h1>

      <section className="mb-6">
        <h2 className="font-semibold">Criar produto rápido</h2>
        <div className="mt-2 flex gap-2">
          <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Título" className="border p-2 rounded flex-1" />
          <input type="number" value={price} onChange={e=>setPrice(Number(e.target.value))} className="border p-2 rounded w-28" />
          <button onClick={createProduct} className="px-3 py-2 bg-green-600 text-white rounded">Criar</button>
        </div>
      </section>

      <section>
        <h2 className="font-semibold">Seus produtos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
          {products.map(p => (
            <div key={p.id} className="p-3 bg-white rounded shadow">
              <div className="font-semibold">{p.title}</div>
              <div className="text-xs text-slate-500">ID: {p.id}</div>
              <div className="text-sm mt-2 font-bold">{Number(p.price || p.price_cents/100 || 0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '../../auth/AuthProvider';
import { useRouter } from 'next/navigation';
import api from '../../../lib/api';

export default function AdminDashboard() {
  const auth = useAuth();
  const router = useRouter();
  useEffect(()=>{ if(!auth.user) router.push('/login'); if(auth.user && auth.user.role !== 'admin') router.push('/login'); }, [auth.user]);
  const [users, setUsers] = useState([]);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const apiBase = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

  useEffect(() => {
    async function load() {
      try {
        const [u, p, o] = await Promise.all([
          api.get('/admin/users').catch(()=> ({ data: [] })),
          api.get('/products').catch(()=> ({ data: [] })),
          api.get('/admin/orders').catch(()=> ({ data: [] }))
        ]);
        setUsers(u.data || []);
        setProducts(p.data || []);
        setOrders(o.data || []);
      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, []);

  return (
    <main className="max-w-7xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>

      <section className="mb-6">
        <h2 className="font-semibold">Usuários</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2">
          {users.length === 0 && <div className="text-sm text-slate-600">Nenhum usuário visível (rota admin).</div>}
          {users.map(u => (
            <div key={u.id} className="p-3 bg-white rounded shadow">
              <div className="font-semibold">{u.name || u.email}</div>
              <div className="text-xs text-slate-500">{u.email}</div>
              <div className="text-xs mt-1">Role: {u.role}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-6">
        <h2 className="font-semibold">Produtos</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2">
          {products.map(p => (
            <div key={p.id} className="p-3 bg-white rounded shadow">
              <div className="font-semibold">{p.title}</div>
              <div className="text-xs text-slate-500">{p.category}</div>
              <div className="text-sm mt-2 font-bold">{Number(p.price || p.price_cents/100 || 0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="font-semibold">Orders</h2>
        <div className="space-y-2 mt-2">
          {orders.length === 0 && <div className="text-sm text-slate-600">Nenhum pedido (rota admin)</div>}
          {orders.map(o => (
            <div key={o.id} className="p-3 bg-white rounded shadow flex justify-between">
              <div>
                <div className="font-semibold">Order #{o.id}</div>
                <div className="text-xs text-slate-500">Status: {o.status}</div>
              </div>
              <div className="text-sm font-bold">{Number(o.amount || 0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

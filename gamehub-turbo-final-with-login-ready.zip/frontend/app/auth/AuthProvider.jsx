'use client';
import React, { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/navigation';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

function getApiBase() {
  return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';
}

export default function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [accessToken, setAccessToken] = useState(null);
  const router = useRouter();

  useEffect(() => {
    // load from localStorage
    const a = localStorage.getItem('gh_access');
    const r = localStorage.getItem('gh_refresh');
    const u = localStorage.getItem('gh_user');
    if (a && u) {
      setAccessToken(a);
      try { setUser(JSON.parse(u)); } catch(e){ setUser(null); }
    }
  }, []);

  useEffect(() => {
    // attach axios interceptor for requests
    const req = axios.interceptors.request.use(config => {
      const token = typeof window !== 'undefined' ? localStorage.getItem('gh_access') : null;
      if (token) config.headers.Authorization = 'Bearer ' + token;
      config.baseURL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';
      return config;
    }, err => Promise.reject(err));

    // response interceptor to handle 401 and try refresh
    const res = axios.interceptors.response.use(
      r => r,
      async error => {
        const original = error.config;
        if (error.response && error.response.status === 401 && !original._retry) {
          original._retry = true;
          const refreshToken = localStorage.getItem('gh_refresh');
          if (!refreshToken) {
            // no refresh - force logout
            logoutLocal();
            return Promise.reject(error);
          }
          try {
            const resp = await axios.post((process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api') + '/auth/refresh', { token: refreshToken });
            const newAccess = resp.data.accessToken;
            localStorage.setItem('gh_access', newAccess);
            setAccessToken(newAccess);
            original.headers.Authorization = 'Bearer ' + newAccess;
            return axios(original);
          } catch (e) {
            logoutLocal();
            return Promise.reject(e);
          }
        }
        return Promise.reject(error);
      }
    );

    return () => {
      axios.interceptors.request.eject(req);
      axios.interceptors.response.eject(res);
    };
  }, []);

  function logoutLocal() {
    localStorage.removeItem('gh_access');
    localStorage.removeItem('gh_refresh');
    localStorage.removeItem('gh_user');
    setUser(null);
    setAccessToken(null);
    try { window.location.href = '/login'; } catch(e) {}
  }

  async function login(email, password, remember=false) {
    const api = getApiBase();
    const res = await axios.post(api + '/auth/login', { email, password });
    const { accessToken, refreshToken, user } = res.data;
    localStorage.setItem('gh_access', accessToken);
    localStorage.setItem('gh_refresh', refreshToken);
    localStorage.setItem('gh_user', JSON.stringify(user));
    setAccessToken(accessToken);
    setUser(user);

    // redirect by role
    if (user.role === 'admin') router.push('/dashboard/admin');
    else if (user.role === 'seller') router.push('/dashboard/seller');
    else router.push('/');

    return user;
  }

  function logout() {
    logoutLocal();
  }

  const value = { user, accessToken, login, logout };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

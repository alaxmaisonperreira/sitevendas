'use client';
import { useAuth } from './AuthProvider';
import Link from 'next/link';

export default function AuthNav() {
  const auth = useAuth();
  return (
    <div className="flex items-center gap-3">
      {auth.user ? (
        <>
          <div className="text-sm">Olá, {auth.user.name || auth.user.email}</div>
          <button onClick={()=>auth.logout()} className="px-2 py-1 border rounded text-sm">Sair</button>
        </>
      ) : (
        <Link href="/login"><span className="px-2 py-1 border rounded text-sm">Entrar</span></Link>
      )}
    </div>
  );
}

'use client';
import { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import axios from 'axios';

export default function CheckoutPage() {
  const [loading, setLoading] = useState(false);
  const stripePk = process.env.NEXT_PUBLIC_STRIPE_PK;
  const stripePromise = loadStripe(stripePk);

  async function handleBuy(productId) {
    setLoading(true);
    try {
      const res = await axios.post((process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api') + '/orders/create-checkout-session', { productId });
      const sessionId = res.data.sessionId;
      const stripe = await stripePromise;
      const { error } = await stripe.redirectToCheckout({ sessionId });
      if (error) console.error(error);
    } catch (err) {
      console.error('Checkout error', err);
      alert('Erro ao iniciar checkout');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-xl font-semibold mb-4">Checkout (demonstração)</h2>
      <p className="mb-4 text-sm text-slate-600">Clique em um produto na home e use este fluxo para testar. Este componente demonstra a integração com Stripe.js.</p>
      <button onClick={()=>handleBuy(1)} disabled={loading} className="px-4 py-2 bg-indigo-600 text-white rounded">Comprar produto #1 (demo)</button>
    </div>
  );
}

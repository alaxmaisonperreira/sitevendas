import axios from 'axios';

export default async function Home() {
  let items = [];
  try {
    const res = await axios.get(process.env.NEXT_PUBLIC_API_URL + '/products');
    items = res.data;
  } catch (e) {
    // SSR fallback: keep empty
  }
  return (
    <main className="max-w-6xl mx-auto p-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold">GameHub Turbo</h1>
        <p className="text-sm text-slate-600">Marketplace de contas, keys e itens digitais</p>
      </header>
      <section>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.length === 0 && <div className="text-sm text-slate-600">Sem itens (verifique API)</div>}
          {items.map(i => (
            <article key={i.id} className="bg-white p-4 rounded shadow">
              <div className="h-40 bg-slate-200 flex items-center justify-center">Imagem</div>
              <h3 className="font-semibold mt-2">{i.title}</h3>
              <div className="text-sm text-slate-500">{i.category} • {i.seller_name}</div>
              <div className="mt-2 font-bold">{Number(i.price).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</div>
            </article>
          ))}
        </div>
      </section>
    </main>
  )
}

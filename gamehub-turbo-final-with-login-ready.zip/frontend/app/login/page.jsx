'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../auth/AuthProvider';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const auth = useAuth();
  const router = useRouter();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');
    try {
      await auth.login(email, password, remember);
      // redirect happens inside login
    } catch (err) {
      console.error(err);
      const msg = err?.response?.data?.error || err?.message || 'Erro ao fazer login';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Entrar</h1>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" type="email" className="w-full border p-2 rounded" required />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Senha" type="password" className="w-full border p-2 rounded" required />
        <div className="flex items-center justify-between">
          <label className="text-sm"><input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)} /> Manter conectado</label>
          <button type="submit" disabled={loading} className="px-4 py-2 bg-indigo-600 text-white rounded">{loading ? 'Entrando...' : 'Entrar'}</button>
        </div>
        {errorMsg && <div className="text-sm text-red-600">{errorMsg}</div>}
      </form>
      <div className="mt-4 text-sm text-slate-600">Usuários de teste: admin@gamehub.com / admin123 ; seller@gamehub.com / seller123 ; buyer@gamehub.com / buyer123</div>
    </main>
  );
}

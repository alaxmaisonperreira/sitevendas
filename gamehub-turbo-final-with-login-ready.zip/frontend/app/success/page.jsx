export default function Success({ searchParams }) {
  const sessionId = searchParams.session_id;
  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Pagamento confirmado</h1>
      <p className="mt-2">Obrigado! Seu pagamento foi confirmado. Session ID: <code>{sessionId}</code></p>
      <p className="mt-4 text-sm">Se a entrega automática estiver configurada, a chave será enviada ao seu painel ou e-mail.</p>
    </main>
  );
}

# GameHub Turbo - Full Marketplace Starter

This package contains a production-minded starter for a digital games marketplace:
- Frontend: Next.js 14 (App Router) + Tailwind CSS
- Backend: Node + Express with security middlewares, JWT auth, Stripe integration scaffold
- PostgreSQL schema and seed scripts
- Docker and docker-compose for local development
- GitHub Actions workflow for basic CI (lint & build)

Quick start:
1. Copy `.env.example` to `.env` and `backend/.env.example` to `backend/.env` and fill secrets.
2. Run: `docker-compose up --build`
3. Frontend: http://localhost:3000
   Backend API: http://localhost:4000/api

This starter emphasizes security: helmet, rate-limiting, input validation, raw Stripe webhook verification, password hashing,
refresh tokens, and prepared scripts to seed the database with test users/products/keys.


## Next steps

After download, copy env files and run `docker-compose up --build`. Run `node backend/scripts/seed.js` to populate test data.

## Deploy guide (Vercel + Railway)

### Frontend (Vercel)
1. Create a Vercel project and connect your repo.
2. Set environment variables in Vercel:
   - NEXT_PUBLIC_API_URL -> https://your-backend-domain/api
   - NEXT_PUBLIC_STRIPE_PK -> your Stripe publishable key
3. Build command: `npm run build` (in /frontend)
4. Output directory: `.next`

### Backend (Railway or Render)
1. Create a new project in Railway or Render, connect repo or push Docker container.
2. Set environment variables (backend):
   - DATABASE_URL
   - JWT_SECRET and JWT_REFRESH_SECRET
   - STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET
   - CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET (if using image uploads)
   - SENTRY_DSN (optional)
3. Configure a webhook in Stripe dashboard pointing to `https://your-backend-domain/webhook` and paste the webhook secret into STRIPE_WEBHOOK_SECRET.

### Cloudinary
- Create an account and add CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET to backend env.
- The uploads endpoint `/api/uploads/image` accepts `multipart/form-data` with field `image` and returns `{ url }`.

### SSL and domain
- Vercel/Railway/Render provide automatic SSL. If using VPS, set up Nginx reverse proxy + certbot.



## Final ready checklist & exact commands

### Local (Docker)
1. Copy envs:
   - `cp backend/.env.example backend/.env`
   - `cp frontend/.env.example frontend/.env`
   - Edit `backend/.env` and `frontend/.env` with your keys.
2. Build and run:
   - `docker-compose up --build -d`
3. Wait until Postgres and backend are healthy, then seed DB:
   - `docker-compose exec backend node scripts/seed.js`
4. Open frontend: http://localhost:3000

### Railway (Backend)
1. Install Railway CLI and login:
   - `curl -sSL https://railway.app/install.sh | sh` (or use binary)
   - `railway login`
2. From repo root:
   - `cd backend`
   - `railway init` (pick project)
   - Set env variables in Railway dashboard (DATABASE_URL, JWT_SECRET, STRIPE keys, CLOUDINARY keys, FRONTEND_URL)
   - `railway up --detach`

### Vercel (Frontend)
1. `vercel login`
2. `vercel` in repo root and follow prompts, or connect Git repo in Vercel UI.
3. Set environment variables in Vercel dashboard:
   - `NEXT_PUBLIC_API_URL` -> `https://<your-backend>/api`
   - `NEXT_PUBLIC_STRIPE_PK` -> your Stripe publishable key

### Stripe webhook (local testing)
1. `stripe login`
2. `stripe listen --forward-to http://localhost:4000/webhook`
3. Copy the `whsec_...` value into `backend/.env` as `STRIPE_WEBHOOK_SECRET`

